import PenTutor from "./components/PenTutor";
function App() {
  

  return (
    <>
    
      <PenTutor/>
      
    </>
  )
}

export default App
