import React from 'react'
import { IoCheckbox } from "react-icons/io5";
import SignupAccount from './SignupAccount';
const FormInput = () => {
  return (
    <>
     <form>
      
      <div className="mb-4">
        <input type="email" name="email" placeholder="Enter your email"
               className="w-full px-4 py-4 my-2 border border-gray-800 rounded-xl
               font-semibold text-xl
                focus:outline-none focus:ring-2 focus:ring-blue-500"/>
      </div>

      
      <div className="mb-6 relative">
  <input
    type="password"
    id="password"
    name="password"
    placeholder="Enter your password"
    className="w-full px-4 py-4 pr-20 border border-gray-500 rounded-xl 
           font-semibold text-xl
           focus:outline-none focus:ring-2 focus:ring-blue-500"
  />
  <a
    href="#"
    className="absolute right-4 top-1/2 transform -translate-y-1/2 text-md text-gray-600 "
  >
    Forget?
  </a>
</div>


     
      <button type="submit"
              className="w-full bg-gray-200 text-gray-600 font-semibold py-4 px-4 rounded-xl hover:bg-blue-200 transition duration-200 text-xl">
        Sign In
      </button>
      <p className="flex items-center justify-center mt-5 text-gray-900 text-xl font-semibold">
  <IoCheckbox className="mr-2 text-xl" />
  Keep me signed in
</p>


<div className="flex items-center my-6">
  <div className="flex-grow border-t border-gray-600"></div>
  <span className="mx-4 text-gray-600 text-xl font-bold">or sign in with </span>
  <div className="flex-grow border-t border-gray-600"></div>
</div>

<SignupAccount/>
    </form>
      
    </>
  )
}

export default FormInput 
