import React from 'react';
import FormInput from './FormInput';
import { PiLessThanThin } from "react-icons/pi";
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

const PenTutor = () => {
  return (
    <div className='w-[40%] mx-auto p-4'>
      <div className='flex justify-center items-center space-x-2'>
        <h1 className='text-2xl font-bold text-blue-900'>PEN TUTOR</h1>
        <select className='mx-1'>
          {/* <option value=""> Select Option </option> */}
        </select>
      </div>

      <div className='mt-4 flex items-center text-gray-500 text-lg font-semibold mx-8 mb-5'>
        <PiLessThanThin className='mr-1' />
        <p>  </p>
        <span> Back</span>
      </div>

    <FormInput/>
      
    </div>
  );
};

export default PenTutor;
