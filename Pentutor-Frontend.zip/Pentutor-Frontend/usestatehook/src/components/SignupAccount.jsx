import React from 'react';
import { FaKey, FaApple, FaFacebook } from "react-icons/fa";
import { FcGoogle } from "react-icons/fc";

const SignupAccount = () => {
  const icons = [
    { id: 1, icon: <FaKey /> },
    { id: 2, icon: <FaApple /> },
    { id: 3, icon: <FcGoogle /> },
    { id: 4, icon: <FaFacebook /> },
  ];

  return (<>
    <ul className="flex justify-center space-x-10 mt-6 ">
      {icons.map((item) => (
        <li
          key={item.id}
          className="p-5 bg-white border border-gray-300 rounded-xl text-xl hover:bg-gray-100 cursor-pointer transition"
        >
          {item.icon}
        </li>
      ))} 
    </ul>
    <div className='mt-8 flex justify-center '> Don't have an account? Sign Up </div>
 </> );
};

export default SignupAccount;
